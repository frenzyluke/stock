# TWSE_Python_crawler
easy python web crawler sharing
Basic function
<a href="https://youtu.be/IqrFMiJfHBU">Discription</a>

Enpowered vsrsion
<a href ="https://www.youtube.com/watch?v=kurBNu1qobM&t=3s"> Function Enhanced version </a>
