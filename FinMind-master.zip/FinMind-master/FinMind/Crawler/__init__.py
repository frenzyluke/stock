#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Aug  2 00:11:48 2018

@author: linsam
"""

# __init__

__version__ = "1.0.81"
