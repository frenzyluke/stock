API_HOST = "http://api.finmindtrade.com/api/v3"
